package Cartoes;

public class Shopping {
	public static void main(String[] args) {
		
		CartaoPrePago cartaoPP1 = new CartaoPrePago("1234 5678 9012 3456", "Joaozinho", 2028, 9);
		CartaoCashBack cartaoCB1 = new CartaoCashBack("5678 9012 3456 7890", "Mariazinha", 2030, 7, 1);
		CartaoCashBack cartaoCB2 = new CartaoCashBack("9012 3456 7890 1234", "Zequinha", 2029, 8, 2);
		CartaoCashBack cartaoCB3 = new CartaoCashBack("3456 7890 1234 5678", "Luluzinha", 2027, 6, 3);
		
		System.out.println("Exibindo saldos");
		System.out.println( cartaoPP1.exibirInfo() );
		System.out.println( cartaoCB1.exibirInfo() );
		System.out.println( cartaoCB2.exibirInfo() );
		System.out.println( cartaoCB3.exibirInfo() );
		
		System.out.println("Adicionando R$ 1.000,00");
		cartaoPP1.adicionarCredito(1000);
		cartaoCB1.adicionarCredito(1000);
		cartaoCB2.adicionarCredito(1000);
		cartaoCB3.adicionarCredito(1000);
		
		System.out.println( cartaoPP1.exibirInfo() );
		System.out.println( cartaoCB1.exibirInfo() );
		System.out.println( cartaoCB2.exibirInfo() );
		System.out.println( cartaoCB3.exibirInfo() );
		
		System.out.println("Comprando R$ 1.000,00");
		cartaoPP1.comprar(1000);
		cartaoCB1.comprar(1000);
		cartaoCB2.comprar(1000);
		cartaoCB3.comprar(1000);
		
		System.out.println("Exibindo saldos");
		System.out.println( cartaoPP1.exibirInfo() );
		System.out.println( cartaoCB1.exibirInfo() );
		System.out.println( cartaoCB2.exibirInfo() );
		System.out.println( cartaoCB3.exibirInfo() );
	}
}
