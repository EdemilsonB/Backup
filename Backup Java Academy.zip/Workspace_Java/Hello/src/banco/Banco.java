package banco;

public class Banco {

	public static void main(String args[]) {
		
		Conta contaA = new Conta("Joaozinho (comum)","123.456.789-01",1,0);
		System.out.println(contaA.exibirInfo());
		
		ContaEspecial contaB = new ContaEspecial("Mariazinha (especial)","234.567.890-12",2,0,1000);
		System.out.println(contaB.exibirInfo());
		
		System.out.println("Creditando R$ 1.000,00");
		contaA.creditar(1000);
		contaB.creditar(1000);
		System.out.println(contaA.exibirInfo());
		System.out.println(contaB.exibirInfo());
		
		System.out.println("Debitando R$ 900,00");
		contaA.debitar(900);
		contaB.debitar(900);
		System.out.println(contaA.exibirInfo());
		System.out.println(contaB.exibirInfo());
		
		System.out.println("Debitando R$ 900,00");
		contaA.debitar(900);
		contaB.debitar(900);
		System.out.println(contaA.exibirInfo());
		System.out.println(contaB.exibirInfo());
	
		System.out.println("Debitando R$ 300,00");
		contaA.debitar(300);
		contaB.debitar(300);
		System.out.println(contaA.exibirInfo());
		System.out.println(contaB.exibirInfo());
	}
}
