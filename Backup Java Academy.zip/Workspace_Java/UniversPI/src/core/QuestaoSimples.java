package core;

public class QuestaoSimples {
	protected String enunciado;
	protected String resposta;
		
	public QuestaoSimples(String enunciado, String resposta) {
		super();
		this.enunciado = enunciado;
		this.resposta = resposta;
	}

	public String aplicarQuestao () {
		return "Q: " + this.enunciado;
	}
	
	public boolean corrigir(String resposta) {
		return this.resposta.equals(resposta);
	}

	public String getEnunciado() {
		return enunciado;
	}
}
