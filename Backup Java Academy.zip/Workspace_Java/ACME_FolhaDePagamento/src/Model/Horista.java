package Model;

public class Horista extends Funcionario {

	private float valorHora;
	private int numeroHoras;
	
	public Horista(String nome, int numeroRegistro, float valorHora, int numeroHoras) {
		super(nome, numeroRegistro);
		this.valorHora = valorHora;
		this.numeroHoras = numeroHoras;
	}

	public float calcularSalario() {
		return ( valorHora * numeroHoras );
	}
	
	public String exibirInfo() {
		return "Nome: " + super.nome + " | Registro: " + super.numeroRegistro + " | Sal�rio calculado: R$ " + String.format("%,.2f", this.calcularSalario());
	}
	
	public float getValorHora() {
		return valorHora;
	}

	public void setValorHora(float valorHora) {
		this.valorHora = valorHora;
	}

	public int getNumeroHoras() {
		return numeroHoras;
	}

	public void setNumeroHoras(int numeroHoras) {
		this.numeroHoras = numeroHoras;
	}
	
	
	
}
