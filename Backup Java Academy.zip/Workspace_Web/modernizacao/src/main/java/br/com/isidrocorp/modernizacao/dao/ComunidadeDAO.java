package br.com.isidrocorp.modernizacao.dao;

import org.springframework.data.repository.CrudRepository;

import br.com.isidrocorp.modernizacao.model.Comunidade;

public interface ComunidadeDAO extends CrudRepository <Comunidade, Integer> {

}
