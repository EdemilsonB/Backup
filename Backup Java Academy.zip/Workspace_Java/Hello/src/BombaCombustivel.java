
public class BombaCombustivel {
	// atributos
	private int nroBomba;
	private String combustivel;
	private double valorPorLitroCombustivel;
	private double qtdeCombustivel;
	private double valorAPagar;
	private double acumuloLitros;
	private double acumuloReais;
	
	public BombaCombustivel(int nroBomba, String combustivel, double valorPorLitroCombustivel) {
		super();
		this.nroBomba = nroBomba;
		this.combustivel = combustivel;
		this.valorPorLitroCombustivel = valorPorLitroCombustivel;
		this.qtdeCombustivel = 0.0;
		this.valorAPagar = 0.0;
		this.acumuloLitros = 0.0;
		this.acumuloReais = 0.0;
	}

	public int getNroBomba() {
		return nroBomba;
	}

	public String getCombustivel() {
		return combustivel;
	}

	public double getValorPorLitroCombustivel() {
		return valorPorLitroCombustivel;
	}

	public double getQtdeCombustivel() {
		return qtdeCombustivel;
	}

	public void setQtdeCombustivel(double qtdeCombustivel) {
		this.qtdeCombustivel = qtdeCombustivel;
		this.acumuloLitros += this.qtdeCombustivel;
		this.valorAPagar = this.valorPorLitroCombustivel * this.qtdeCombustivel;
		this.acumuloReais += this.valorAPagar;
	}

	public double getValorAPagar() {
		return valorAPagar;
	}

	public void setValorAPagar(double valorAPagar) {
		this.valorAPagar = valorAPagar;
		this.acumuloReais += this.valorAPagar;
		this.qtdeCombustivel = this.valorAPagar / this.valorPorLitroCombustivel;
		this.acumuloLitros += this.qtdeCombustivel;		
	}
	
	public String getInfo() {
		return ( "------  Ticket / Recibo de Abastecimento -------------------------------------------------------------\n" +
	             "Bomba: " + this.nroBomba + ", Combustivel: " + this.combustivel + ", Valor do Litro: " + String.format( "%.3f", this.valorPorLitroCombustivel) + ", Qtde. Litros: " + String.format("%.2f", this.qtdeCombustivel) + ", Valor a Pagar: R$ " + String.format("%.2f", this.valorAPagar) +
	             "\n------------------------------------------------------------------------------------------------------");
	}
	
	public String getFechamento() {
		return ( "Bomba: " + this.nroBomba + ", Combustivel: " + this.combustivel + ", Valor do Litro: " + String.format( "%.3f", this.valorPorLitroCombustivel) + ", Qtde. Total Litros: " + String.format("%.2f", this.acumuloLitros) + ", Valor Total: R$ " + String.format("%.2f", this.acumuloReais));
	}
}
