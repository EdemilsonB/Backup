package ui;

import Model.Chefe;
import Model.Comissionado;
import Model.Empreiteiro;
import Model.Funcionario;
import Model.Horista;

public class GeradorRecibosPagamento {
	public static void main(String[] args) {
		
		Funcionario ListaFuncionarios[] = new Funcionario[4];
		
		ListaFuncionarios[0] = new Chefe("Manda Chuva", 1, 5000, 10, 100);
		ListaFuncionarios[1] = new Comissionado("M�rio Iludido", 2, 2000, 20);
		ListaFuncionarios[2] = new Horista("Z� Horinha", 3, 25, 172);
		ListaFuncionarios[3] = new Empreiteiro("Jo�o Fininho", 4, 15000);
		
		for ( Funcionario q : ListaFuncionarios ) {
			System.out.println( q.exibirInfo() );
		}
	}
}
