
public class empregadoTeste {
	public static void main(String[] args) {
		empregado e1 = new empregado();
		empregado e2 = new empregado();

		e1.nome = "Joaozinho";
		e1.cargo = "Presidente";
		e1.salario = 10000.0;

		e2.nome = "Mariazinha";
		e2.cargo = "Vice-Presidente";
		e2.salario = 9500.0;
		
		e1.imprimir();
		e1.aumentarSalario(5);
		e1.imprimir();
		
		e2.imprimir();
		e2.aumentarSalario(10);
		e2.imprimir();
	}
}
