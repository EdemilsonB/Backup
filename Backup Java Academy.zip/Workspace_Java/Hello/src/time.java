
public class time {
	private int hora;
	private int minuto;
	private int segundo;
	
	public int getHora() {
		return (hora);
	}
	public void setHora(int hora) {
		this.hora = hora;
	}
	public int getMinuto() {
		return (minuto);
	}
	public void setMinuto(int minuto) {
		this.minuto = minuto;
	}
	public int getSegundo() {
		return (segundo);
	}
	public void setSegundo(int segundo) {
		this.segundo = segundo;
	}
	
	public void setTime(int h, int m, int s) {
		if ( (h < 0 || h > 23) || (m < 0 || m > 59) || (s < 0 || s > 59) ) {
			return;
		}
		else {
			this.hora = h;
			this.minuto = m;
			this.segundo = s;
		}
	}
	
	public String exibirHoraUniversal () {
		return ( formatarNumero(this.hora) + ":" + formatarNumero(this.minuto) + ":" + formatarNumero(this.segundo) );
	}
	
	public String exibirHoraPadrao () { 
		if (this.hora == 0 ) { return ( "12" + ":" + formatarNumero(this.minuto) + ":" + formatarNumero(this.segundo) + " AM"); }
		if (this.hora == 12 ) { return ( "12" + ":" + formatarNumero(this.minuto) + ":" + formatarNumero(this.segundo) + " PM"); }
		if (this.hora > 0 && this.hora < 12) { return ( formatarNumero((this.hora)) + ":" + formatarNumero(this.minuto) + ":" + formatarNumero(this.segundo) + " AM"); }
		else { return ( formatarNumero((this.hora - 12)) + ":" + formatarNumero(this.minuto) + ":" + formatarNumero(this.segundo) + " PM"); }
	}
	
	public String formatarNumero(int numero) {
		if (numero < 10) { return ("0" + numero );}
		else { return (numero + "");}
	}
}
