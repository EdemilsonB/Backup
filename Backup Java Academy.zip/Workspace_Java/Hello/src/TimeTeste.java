
public class TimeTeste {
	public static void main (String args[]) {
		time t1 = new time();
		
		t1.setTime(23, 59, 59);
		System.out.println(t1.exibirHoraPadrao());
		System.out.println(t1.exibirHoraUniversal());
		System.out.println("---------------");
		
		t1.setTime(13, 59, 59);
		System.out.println(t1.exibirHoraPadrao());
		System.out.println(t1.exibirHoraUniversal());
		System.out.println("---------------");
		
		t1.setTime(0, 0, 0);
		System.out.println(t1.exibirHoraPadrao());
		System.out.println(t1.exibirHoraUniversal());
		System.out.println("---------------");
		
		t1.setTime(12, 0, 0);
		System.out.println(t1.exibirHoraPadrao());
		System.out.println(t1.exibirHoraUniversal());
		System.out.println("---------------");
		
	}
}
