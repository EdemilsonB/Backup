package br.com.isidrocorp.modernizacao.dto;

public class PercentualQuantidade {
	private double percentual;
	private long quantidade;
	
	public double getPercentual() {
		return percentual;
	}
	public void setPercentual(double percentual) {
		this.percentual = percentual;
	}
	public long getQuantidade() {
		return quantidade;
	}
	public void setQuantidade(long quantidade) {
		this.quantidade = quantidade;
	}
	
}
