
public class Banco {
	static ContaBancaria conta1, conta2, conta3;
	
	public static void main(String[] args) {

		conta1 = new ContaBancaria("123.456.789-01", 1, 2);
		conta2 = new ContaBancaria("234.567.890-12", 2, 3);
		conta3 = new ContaBancaria("345.678.901-23", 3, 4);
		
		System.out.println("--- Posicao inicial das contas --------");
		imprimir();
		
		System.out.println("--- Creditando R$ 1,00 -----------------");
		conta1.creditar(1);
		conta2.creditar(1);
		conta3.creditar(1);
		imprimir();
		
		System.out.println("--- Creditando R$ 100,00 ---------------");
		conta1.creditar(100);
		conta2.creditar(100);
		conta3.creditar(100);
		imprimir();
		
		System.out.println("--- Debitando R$ 11,00 ----------------");
		conta1.debitar(11);
		conta2.debitar(11);
		conta3.debitar(11);
		imprimir();
		
		System.out.println("--- Tentar Debitar R$ 300,00 Conta1 ----");
		if ( conta1.debitar(300.00) ) {
			System.out.println( "Debitou... ERRO !!!");
		}
		else {
			System.out.println( "Nao debitou... OK !!!");
		}
	}
	
	private static void imprimir() {
		System.out.println( conta1.obterInfo() );
		System.out.println( conta2.obterInfo() );
		System.out.println( conta3.obterInfo() );
		System.out.println();
	}
}
