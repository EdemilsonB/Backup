package banco;

public class ContaEspecial extends Conta {
	private float limite;

	public ContaEspecial(String nomeTitular, String cpf, int numeroConta, float saldo, float limite) {
		super(nomeTitular, cpf, numeroConta, saldo);
		this.limite = limite;
	}

	public String exibirInfo() {
		return "Nome do Titular: " + super.nomeTitular + " | CPF: " + super.cpf + " | Numero Conta: " + super.numeroConta + " | Saldo: R$ " + String.format("%,.2f", super.saldo) + " | Limite Especial: R$ " + String.format("%,.2f", this.limite) ; 
	}
	
	public boolean debitar(float valor) {
		if (valor <= (super.saldo + this.limite)) {
			super.saldo -= valor;
			return true;
		}
		else {
			return false;
		}
	}
	
	public float getLimite() {
		return this.limite;
	}

	public void setLimite(float limite) {
		this.limite = limite;
	}
	
	
}
