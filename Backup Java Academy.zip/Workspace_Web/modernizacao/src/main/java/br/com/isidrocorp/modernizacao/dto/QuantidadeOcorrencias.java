package br.com.isidrocorp.modernizacao.dto;

public class QuantidadeOcorrencias {
	private long qtde;

	public QuantidadeOcorrencias(long qtde) {
		this.qtde = qtde;
	}

	public long getQtde() {
		return qtde;
	}

	public void setQtde(long qtde) {
		this.qtde = qtde;
	}
}
