package br.com.isidrocorp.modernizacao.dto;

public class Percentual {
	private double total;

	
	public Percentual(double total) {
		super();
		this.total = total;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}
}
