import java.util.Scanner;
import java.lang.Math;

public class Uri1016 {
    public static void main ( String args[] ) {

        Scanner teclado = new Scanner(System.in) ;
        int distancia = teclado.nextInt() ;
        float tempo = 0 ;

        System.out.printf( "%.0f minutos\n" , distancia / 0.5 ) ;
    }
}