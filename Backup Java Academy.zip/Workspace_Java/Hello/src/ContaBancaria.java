
public class ContaBancaria {
	// atributos
	private String cpf;
	private int numero;
	private int dv;
	private double saldo;
	
	public ContaBancaria ( String cpf, int numero, int dv ) {
		setCpf(cpf);
		setNumero(numero);
		setDv(dv);
		this.saldo = 0.0;
	}
	
	public void creditar (double valor ) {
		this.saldo += valor;
	}
	
	public boolean debitar (double valor ) {
		if ( this.saldo >= valor ) {
			this.saldo -= valor;
			return true;
		}
		else {
			return false;
		}
	}
	
	public String obterInfo () {
		String msg = ( this.cpf + ";" + String.format("%05d", this.numero) + "-" + this.dv + ";" + String.format("R$ %.2f", saldo) );
		return msg;
	}
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public int getDv() {
		return dv;
	}
	public void setDv(int dv) {
		this.dv = dv;
	}
	
	
}
