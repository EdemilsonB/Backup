function carregaInfo(){
    var userSTR = localStorage.getItem("userMod");

    // rotina para verificar se o usuario está ou não autenticado
    if ( ! userSTR ) {
        windows.location = "index.html";
        return;
    }

    // reconverte o dado armazenado no disco para objeto
    var user = JSON.parse( userSTR );

    var strFoto =   `<img src="${user.linkFoto}" width="100%">`;
    var strBio  =   `<h4>${user.nome}</h4>
                     <br>
                     <p><strong>RACF:</strong> ${user.racf}</p>
                     <p><strong>E-mail:</strong> ${user.email}</p>`;
    document.getElementById( "fotoUser" ).innerHTML = strFoto;
    document.getElementById( "bioUser" ).innerHTML = strBio;

    // aqui começo a preencher a lista de comunidades
    var strLista = "<br>";
    for ( i = 0; i < user.comunidades.length; i++ ) {
        var comunidade = user.comunidades[i];
        strLista = strLista + `<div class="row">
                                    <div class="col-8">${comunidade.nome}</div>
                                    <div class="col-2"><a href="novamodernizacao.html?id=${comunidade.id}" class="btn btn-success">Novo</a></div>
                                    <div class="col-2"><a href="extrato.html?id=${comunidade.id}" class="btn btn-warning">Extrato</a></div>
                                </div>`;
    }
    document.getElementById("listaComunidades").innerHTML = strLista;
}

function logout() {
    localStorage.removeItem("userMod");
    window.location = "index.html";
}