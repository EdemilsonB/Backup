package Cartoes;

public class CartaoCashBack extends CartaoPrePago {
	// tipo 1 = GOLD, 2 = SILVER, 3 = BRONZE
	private int tipo;
	

	public CartaoCashBack(String numeroCartao, String nomeTitular, int anoValidade, int mesValidade, int tipo) {
		super(numeroCartao, nomeTitular, anoValidade, mesValidade);
		this.tipo = tipo;
	}

	public boolean comprar(double valor) {
		if ( this.saldo >= valor ) {
			this.saldo -= valor;
			switch (this.tipo ) {
			case 1: // GOLD
				this.saldo += valor * 0.08;
				break;
			case 2: // SILVER
				this.saldo += valor * 0.05;
				break;
			case 3: // BRONZE
				this.saldo += valor * 0.02;
				break;
			}
			return true;
		}
		return false;
	}
	
	public String exibirInfo() {
		return "Nro.Cartao: " + this.numeroCartao + " (" + this.getDescricaoPeloTipo() + ") (" + this.nomeTitular + ") - Saldo: R$ " + String.format("%,.2f", this.saldo);
	}

	public int getTipo() {
		return tipo;
	}


	public void setTipo(int tipo) {
		this.tipo = tipo;
	}
	
	public String getDescricaoPeloTipo () {
		// tipo 1 = GOLD, 2 = SILVER, 3 = BRONZE
		String Descricao = "";
		switch (this.tipo ) {
		case 1:
			Descricao = "GOLD";
			break;
		case 2:
			Descricao = "SILVER";
			break;
		case 3:
			Descricao = "BRONZE";
			break;
		}
		return Descricao;
	}
	
	public void setTipoPelaDescricao (String Descricao) {
		// tipo 1 = GOLD, 2 = SILVER, 3 = BRONZE
		switch (Descricao ) {
		case "GOLD":
			this.tipo = 1;
			break;
		case "SILVER":
			this.tipo = 2;
			break;
		case "BRONZE":
			this.tipo = 3;
			break;
		}
		return;
	}
}
