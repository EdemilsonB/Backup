package userInterface;

import java.util.Scanner;

import core.QuestaoComDica;
import core.QuestaoMultiplaEscolha;
import core.QuestaoSimples;

public class AplicarProva {
	public static void main(String[] args) {
		
		QuestaoSimples qS1 = new QuestaoSimples("Quem foi Oscar Alho?", "Filosofo do Seculo XX");
		QuestaoMultiplaEscolha qME1 = new QuestaoMultiplaEscolha("Quem descobriu o Brasil? (digite a resposta por extenso)", "PAC", "a) PAC", "b) Bozonaro","c) Tiririca","d) Donald Trump");
		QuestaoComDica qCD1 = new QuestaoComDica("Qual a raiz quadrada de Zero?","Nao ha","(Dica) Da ruim");
		Scanner teclado = new Scanner(System.in);
		String resposta;
		
		System.out.println("===============================================================");
		System.out.println("------------------      Aplicando prova      ------------------");
		System.out.println("===============================================================");
		
		System.out.println( qS1.aplicarQuestao() );
		resposta = teclado.nextLine();
		if ( qS1.corrigir(resposta) ) { System.out.println("Resposta CORRETA"); }
		else { System.out.println("Resposta INCORRETA"); }
		
		System.out.println( qME1.aplicarQuestao() );
		resposta = teclado.nextLine();
		if ( qME1.corrigir(resposta) ) { System.out.println("Resposta CORRETA"); }
		else { System.out.println("Resposta INCORRETA"); }
		
		System.out.println( qCD1.aplicarQuestao() );
		resposta = teclado.nextLine();
		if ( qCD1.corrigir(resposta) ) { System.out.println("Resposta CORRETA"); }
		else { System.out.println("Resposta INCORRETA"); }
		
		teclado.close();
	}
}
