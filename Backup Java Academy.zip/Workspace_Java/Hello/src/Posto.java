import java.util.Scanner;

public class Posto {
	public static void main(String[] args) {
		
		Scanner teclado = new Scanner(System.in);
		
		BombaCombustivel bomba1 = new BombaCombustivel( 1, "Gasolina", 5.009 );
		BombaCombustivel bomba2 = new BombaCombustivel( 2, "Etanol",   3.499 );
		BombaCombustivel bomba3 = new BombaCombustivel( 3, "Diesel",   3.381 );
		BombaCombustivel bombaAtual = bomba1;
		
		System.out.println("====================================================");
		System.out.println("--- ISIDRO'S CORPORATION ---------------------------");
		System.out.println("====================================================");
		System.out.println("--- Relatorio de Inicio do dia ---------------------");
		System.out.println( bomba1.getFechamento() );
		System.out.println( bomba2.getFechamento() );
		System.out.println( bomba3.getFechamento() );
		System.out.println("----------------------------------------------------");
		
		int opcaoCombustivel = 0, opcaoLitrosOuReais = 0;
		double qtdade = 0.0;
		while ( opcaoCombustivel != 4 ) {
			System.out.println("====================================================");
			System.out.println("--- Que vai ser patrao / madame ? ------------------");
			System.out.println("-- 1) Gasolina  2) Etanol   3) Diesel   4) Sextou --");
			opcaoCombustivel = teclado.nextInt();
			if (opcaoCombustivel == 4 ) {
				break;
			}
			switch (opcaoCombustivel) {
			case 1:
				bombaAtual = bomba1;
				break;
			case 2:
				bombaAtual = bomba2;
				break;
			case 3:
				bombaAtual = bomba3;
				break;
			}
			System.out.println("--- Dirijindo ate a respectiva Bomba .... ----------");
			System.out.println("----------------------------------------------------");
			System.out.println("--- Abaster em:    1) Litros       2) Reais (R$)  ---");
			opcaoLitrosOuReais = teclado.nextInt();
			System.out.println("--- Quanto ?                                      ---");
			qtdade = teclado.nextDouble();
			System.out.println("--- Inserindo valores na Bomba e abastecendo .... ---");
			switch (opcaoLitrosOuReais) {
			case 1:
				bombaAtual.setQtdeCombustivel(qtdade);
				System.out.println( bombaAtual.getInfo() );
				break;
			case 2:
				bombaAtual.setValorAPagar(qtdade);
				System.out.println( bombaAtual.getInfo() );
				break;
			}
		}
		
		System.out.println("====================================================");
		System.out.println("--- ISIDRO'S CORPORATION ---------------------------");
		System.out.println("====================================================");
		System.out.println("--- Relatorio de Fim do dia ------------------------");
		System.out.println( bomba1.getFechamento() );
		System.out.println( bomba2.getFechamento() );
		System.out.println( bomba3.getFechamento() );
		System.out.println("----------------------------------------------------");
		
		
		teclado.close();
	}
}
